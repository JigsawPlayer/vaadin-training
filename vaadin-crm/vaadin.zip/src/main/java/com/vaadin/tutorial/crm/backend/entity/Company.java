package com.vaadin.tutorial.crm.backend.entity;

public class Company {
}
